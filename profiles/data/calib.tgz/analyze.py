#!/usr/bin/env python3
"""Extract KV-store I/O distributions from a threaded strace log.

Handles strace -f split syscalls (<unfinished ...> / <... resumed>).
"""
import collections
import json
import re
import sys

RAW = sys.argv[1] if len(sys.argv) > 1 else "/root/cal/strace.raw"
STORE = sys.argv[2] if len(sys.argv) > 2 else "/root/kvstore"

open_re = re.compile(r'openat\((?:[^,]+), "([^"]+)"')
io_re = re.compile(r'^(\d+)\s+(pread64|pwrite64|read|write)\((\d+),.*=\s*(-?\d+)')
unfin_re = re.compile(r'^(\d+)\s+(pread64|pwrite64|read|write)\((\d+),.*<unfinished')
resum_re = re.compile(r'^(\d+)\s+<\.\.\. (pread64|pwrite64|read|write) resumed>.*=\s*(-?\d+)')

fds = {}
pending = {}
sizes = collections.Counter()
by_op = collections.Counter()
per_file_bytes = collections.Counter()
read_sizes, write_sizes = [], []
seq = []

def record(op, fd, ret):
    path = fds.get(fd, "")
    if STORE not in path or ret <= 0:
        return
    sizes[ret] += 1
    by_op[op] += 1
    per_file_bytes[path] += ret
    (read_sizes if "read" in op else write_sizes).append(ret)
    seq.append((op, path, ret))

for line in open(RAW, errors="replace"):
    mo = open_re.search(line)
    if mo and "= " in line and "unfinished" not in line:
        try:
            fd = int(line.rsplit("= ", 1)[1].split()[0])
        except (ValueError, IndexError):
            continue
        if fd >= 0:
            fds[fd] = mo.group(1)
        continue
    mu = unfin_re.match(line)
    if mu:
        pending[(mu.group(1), mu.group(2))] = int(mu.group(3))
        continue
    mr = resum_re.match(line)
    if mr:
        fd = pending.pop((mr.group(1), mr.group(2)), None)
        if fd is not None:
            record(mr.group(2), fd, int(mr.group(3)))
        continue
    mi = io_re.match(line)
    if mi:
        record(mi.group(2), int(mi.group(3)), int(mi.group(4)))

def hist(vals, label):
    if not vals:
        print(f"{label}: none")
        return
    vals = sorted(vals)
    tot = sum(vals)
    print(f"{label}: n={len(vals)} total={tot/2**20:.1f}MiB "
          f"min={vals[0]} p50={vals[len(vals)//2]} "
          f"p90={vals[int(len(vals)*0.9)]} max={vals[-1]}")
    c = collections.Counter()
    for v in vals:
        b = 1 << (v - 1).bit_length() if v > 1 else 1
        c[b] += 1
    for b in sorted(c):
        pct = 100.0 * c[b] / len(vals)
        if pct >= 0.5:
            print(f"    <={b:>9} ({b/1024:>8.1f}K): {c[b]:>7}  {pct:5.1f}%")

print(f"=== KV store I/O ({STORE}) ===")
print("ops:", dict(by_op))
hist(read_sizes, "READ sizes (syscall)")
hist(write_sizes, "WRITE sizes (syscall)")
print("distinct files:", len(per_file_bytes))

ext, cur = [], None
for op, path, size in seq:
    if cur and cur[0] == op and cur[1] == path:
        cur = (op, path, cur[2] + size)
    else:
        if cur:
            ext.append(cur)
        cur = (op, path, size)
if cur:
    ext.append(cur)
hist([e[2] for e in ext if "read" in e[0]], "READ logical extents")
hist([e[2] for e in ext if "write" in e[0]], "WRITE logical extents")

rext = sorted(e[2] for e in ext if "read" in e[0])
if rext:
    c = collections.Counter()
    for v in rext:
        b = 1 << (v - 1).bit_length() if v > 1 else 1
        c[b] += 1
    top = sorted(c.items(), key=lambda kv: -kv[1])[:4]
    tot = sum(n for _, n in top)
    parts = ["%dk/%d" % (b // 1024, round(100 * n / tot)) for b, n in sorted(top)]
    print("\nSUGGESTED kvspill bssplit (read):", ":".join(parts))
    print("SUGGESTED extent p50: %d KiB" % (rext[len(rext)//2] // 1024))
