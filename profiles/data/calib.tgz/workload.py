import random, time
from vllm import LLM, SamplingParams
from vllm.config import KVTransferConfig

random.seed(1)
ktc = KVTransferConfig(kv_connector="LMCacheConnectorV1", kv_role="kv_both")
llm = LLM(model="Qwen/Qwen2.5-1.5B-Instruct", gpu_memory_utilization=0.30,
          max_model_len=8192, enforce_eager=True, enable_prefix_caching=False, kv_transfer_config=ktc)
sp = SamplingParams(temperature=0.0, max_tokens=8)
base = "You are a meticulous assistant. Answer briefly. " * 250
ctxs = [base + f"\nThread {i}: " + (f"fact {i}-%d. " % i) * 400 for i in range(10)]
t0 = time.time()
for epoch in range(3):
    order = list(range(len(ctxs))); random.shuffle(order)
    for i in order:
        llm.generate([ctxs[i] + f"\nEpoch {epoch}. Summarize."], sp)
    print(f"epoch {epoch} done t={time.time()-t0:.1f}s", flush=True)
print("WORKLOAD_DONE", flush=True)
